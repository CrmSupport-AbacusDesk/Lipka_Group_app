import { NgModule } from '@angular/core';
// import { IonicPageModule } from 'ionic-angular';
// import { SitePopoverPage } from './site-popover';

@NgModule({
  declarations: [
    // SitePopoverPage,
  ],
  imports: [
    // IonicPageModule.forChild(SitePopoverPage),
  ],
})
export class SitePopoverPageModule {}
